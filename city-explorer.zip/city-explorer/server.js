const express = require('express');
const path = require('path');

const app = express();
app.use(express.json({ limit: '2mb' }));

// Sert le fichier HTML principal
app.use(express.static(path.join(__dirname, 'public')));

// Proxy sécurisé vers l'API Anthropic
// La clé API reste sur le serveur, invisible pour les utilisateurs
app.post('/api/claude', async (req, res) => {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: { message: 'Clé API non configurée sur le serveur.' } });
  }

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'anthropic-version': '2023-06-01',
        'x-api-key': apiKey,
      },
      body: JSON.stringify(req.body),
    });

    const data = await response.json();
    res.status(response.status).json(data);
  } catch (err) {
    console.error('Erreur API:', err.message);
    res.status(500).json({ error: { message: 'Erreur serveur : ' + err.message } });
  }
});

// Toutes les autres routes → index.html
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log('City Explorer démarré sur le port ' + PORT);
});
