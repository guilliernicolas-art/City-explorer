# City Explorer — Guide de déploiement

## Ce que vous obtiendrez
Une URL publique (ex: `city-explorer.onrender.com`) que vous partagez à votre famille.
L'application fonctionne sur mobile et desktop, sans installation.

---

## Étape 1 — Créer une clé API Anthropic (5 min)

1. Allez sur **console.anthropic.com**
2. Créez un compte (email + mot de passe)
3. Allez dans **"API Keys"** → cliquez **"Create Key"**
4. Donnez-lui un nom (ex: "city-explorer")
5. **Copiez la clé** (commence par `sk-ant-...`) — elle ne s'affiche qu'une fois
6. Ajoutez 5€ de crédit dans "Billing" → suffisant pour des mois d'usage familial

---

## Étape 2 — Créer un compte GitHub (5 min)

1. Allez sur **github.com**
2. Cliquez **"Sign up"** → créez un compte
3. Une fois connecté, cliquez sur **"+"** en haut à droite → **"New repository"**
4. Nom du dépôt : `city-explorer`
5. Laissez tout par défaut → cliquez **"Create repository"**

## Étape 3 — Déposer les fichiers sur GitHub (5 min)

Dans votre nouveau dépôt GitHub vide :
1. Cliquez **"uploading an existing file"**
2. Glissez-déposez les 3 fichiers/dossier :
   - `server.js`
   - `package.json`
   - Le dossier `public/` (avec `index.html` dedans)
3. Cliquez **"Commit changes"**

---

## Étape 4 — Déployer sur Render (10 min)

1. Allez sur **render.com**
2. Cliquez **"Get Started"** → connectez-vous avec votre compte GitHub
3. Cliquez **"New +"** → **"Web Service"**
4. Sélectionnez votre dépôt `city-explorer`
5. Remplissez :
   - **Name** : `city-explorer`
   - **Runtime** : `Node`
   - **Build Command** : `npm install`
   - **Start Command** : `npm start`
   - **Plan** : `Free`
6. Descendez jusqu'à **"Environment Variables"** → cliquez **"Add Environment Variable"** :
   - **Key** : `ANTHROPIC_API_KEY`
   - **Value** : collez votre clé `sk-ant-...`
7. Cliquez **"Create Web Service"**

Render va déployer automatiquement (2-3 minutes).
Vous obtenez une URL comme `https://city-explorer-xxxx.onrender.com`

---

## Étape 5 — Partager le lien

Envoyez simplement l'URL à votre famille. C'est tout !

**Note** : Sur le plan gratuit de Render, l'app se "met en veille" après 15 min d'inactivité.
Le premier chargement après une pause peut prendre ~30 secondes.
